# EB Calculator - Updated GitHub / Vercel Package

Google Apps Script Web App URL:
https://script.google.com/macros/s/AKfycbxY3x-zNSKOzNOJJC9WOfiQ62_kIMvQ82azhJo00fdhST9w2ARG6HD5We1z7X_41UH7/exec

Deployment / Web App ID:
AKfycbxY3x-zNSKOzNOJJC9WOfiQ62_kIMvQ82azhJo00fdhST9w2ARG6HD5We1z7X_41UH7

Upload `index.html` and `vercel.json` to the root of your GitHub repository, then redeploy on Vercel.
